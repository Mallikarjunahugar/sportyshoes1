package com.shoe.exception;

public class MyResourceNotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public MyResourceNotFoundException(String errorMessage) {
		super(errorMessage);
	}
}
