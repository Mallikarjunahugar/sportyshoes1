package com.shoe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shoe.model.ProductModel;

public interface ProductRepository extends JpaRepository<ProductModel, Integer> {

}
