package com.shoe.exception;

public class MyResourceNotDeletedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public MyResourceNotDeletedException(String errorMessage) {
		super(errorMessage);
	}
}
