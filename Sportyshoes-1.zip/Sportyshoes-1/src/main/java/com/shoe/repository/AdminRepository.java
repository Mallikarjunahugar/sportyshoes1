package com.shoe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shoe.model.AdminModel;

public interface AdminRepository extends JpaRepository<AdminModel, Integer> {

}
