package com.shoe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sportyshoes1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
