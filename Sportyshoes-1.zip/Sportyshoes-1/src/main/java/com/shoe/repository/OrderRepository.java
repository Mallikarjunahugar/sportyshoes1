package com.shoe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shoe.model.OrderModel;

public interface OrderRepository extends JpaRepository<OrderModel, Integer> {

}
