package com.shoe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class Sportyshoes1Application {

	public static void main(String[] args) {
		SpringApplication.run(Sportyshoes1Application.class, args);
		System.out.println("Welcome to Shoe Shop");
	}
	
}
