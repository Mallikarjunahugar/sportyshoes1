package com.shoe.exception;

public class MyResourceNotUpdatedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public MyResourceNotUpdatedException(String errorMessage) {
		super(errorMessage);
	}
}
