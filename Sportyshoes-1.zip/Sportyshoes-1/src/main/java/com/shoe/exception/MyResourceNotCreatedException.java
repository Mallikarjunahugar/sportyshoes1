package com.shoe.exception;

public class MyResourceNotCreatedException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public MyResourceNotCreatedException(String errorMessage) {
		super(errorMessage);
	}
}
