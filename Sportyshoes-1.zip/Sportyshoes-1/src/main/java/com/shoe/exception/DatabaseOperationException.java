package com.shoe.exception;

public class DatabaseOperationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DatabaseOperationException(String errorMessage) {
		super(errorMessage);
	}
	
	public DatabaseOperationException(String errorMessage, Exception e) {
		super(errorMessage, e);
	}

}
